### Homework Assignment #18

**Question 1 (4)**:  
Give the reduced cost matrix and the lower bound given the following distance matrix for the TSP problem.

| []() | | | |
| --- | --- | --- | --- |
| $\infty$ | 7 | 3 | 12 |
| 3 | $\infty$ | 6 | 14 |
| 5 | 8 | $\infty$ | 6 |
| 9 | 3 | 5 | $\infty$ |

**Question 2 (6)**:  
Question 9.3 from the book. See section 5.4 of the book for a definition of Set Cover.


